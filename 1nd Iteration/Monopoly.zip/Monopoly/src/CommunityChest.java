
public class CommunityChest extends Square {

	public CommunityChest(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
