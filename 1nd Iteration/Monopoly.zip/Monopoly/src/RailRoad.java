
public class RailRoad extends Square{

	public RailRoad(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
