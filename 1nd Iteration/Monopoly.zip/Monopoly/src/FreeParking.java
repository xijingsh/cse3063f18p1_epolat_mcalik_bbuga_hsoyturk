
public class FreeParking extends Square{

	 public FreeParking(String nameOfSquare) {
	        super(nameOfSquare, 0, 0);
	    }

}
