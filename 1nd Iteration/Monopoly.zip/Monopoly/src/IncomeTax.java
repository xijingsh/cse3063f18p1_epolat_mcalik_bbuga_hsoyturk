
public class IncomeTax extends Square{

	public IncomeTax(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }


}
