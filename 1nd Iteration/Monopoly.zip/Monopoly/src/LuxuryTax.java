
public class LuxuryTax extends Square{
	public LuxuryTax(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
