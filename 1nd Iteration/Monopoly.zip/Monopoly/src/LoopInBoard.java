
public class LoopInBoard extends Square{
	public LoopInBoard(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
