
public class GoToJail extends Square {

	public GoToJail(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }


}
