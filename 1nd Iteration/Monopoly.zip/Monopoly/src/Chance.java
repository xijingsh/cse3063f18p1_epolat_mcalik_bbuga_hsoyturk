
public class Chance extends Square {

	public Chance(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
