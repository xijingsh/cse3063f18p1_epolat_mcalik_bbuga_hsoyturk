
public class Avenue extends Square {

	public Avenue(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

	

}
