
public class Utilities extends Square{

	public Utilities(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }

}
