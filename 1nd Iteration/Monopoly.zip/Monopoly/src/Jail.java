
public class Jail extends Square{
	
	public Jail(String nameOfSquare) {
        super(nameOfSquare, 0, 0);
    }


}
